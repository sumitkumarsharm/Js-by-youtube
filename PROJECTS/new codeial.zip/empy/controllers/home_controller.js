module.exports.home = function(req, res){
   console.log(req.cookies);
   res.cookie('user_id',786);
    return res.render('home.ejs',{
        title: "Home"
    });
};
//second controller
module.exports.Action = function(req,res){
    return res.end('<h1>this is a second controller that is use to adding somthing </h1>')
}

//third controller
module.exports.Reply = function(req,res){
    return res.end('<h1>Controllers are responsible for handling incoming requests and returning responses to the client. A controllers purpose is to receive specific requests for the application.</h1>');;
}