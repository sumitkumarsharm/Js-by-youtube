module.exports.social = function(req,res){
    return res.render('social.ejs',{
        title:"Social"
    })
};