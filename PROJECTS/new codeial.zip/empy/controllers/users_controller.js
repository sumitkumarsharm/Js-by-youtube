
// const User = require("../models/user");
// // Get the user's profile

// module.exports.profile = async function(req, res){
//     if(req.cookies.user_id){
//       const user = await User.findById(req.cookies.user_id);
//         if(user){
//           return res.render('user_profile',{
//             title:"User Profile",
//             user:user,
//           })
//         }
//       }
//       return res.redirect('/users/sign-in');
//     }    


// //render the Sign up page
// module.exports.signUp = function (req, res) {
//   return res.render("user_sign_up", {
//     title: "Codeial | Sign Up",
//   });
// };

// //render the sign in page

// module.exports.signIn = function (req, res) {
//   return res.render("user_sign_in", {
//     title: "Codeial | Sign In",
//   });
// };



// // for sign up
// module.exports.create = async function (req, res) {
//   if (req.body.password != req.body.confirm_password) {
//     return res.redirect("back");
//   }

//   // Find the user by email.
//   const user = await User.findOne({ email: req.body.email });

//   // If the user does not exist, create the user.
//   if (!user) {
//     await User.create(req.body);
//   }



//   // Redirect the user to the sign in page.
//   return res.redirect("/users/sign-in");
// };
//__________________________________________________
// get the sign up data without is
// module.exports.create = function(req, res){
//   if (req.body.password != req.body.confirm_password){
//       return res.redirect('back');
//   }

//   User.findOne({email: req.body.email}, function(err, user){
//       if(err){console.log('error in finding user in signing up'); return}

//       if (!user){
//           User.create(req.body, function(err, user){
//               if(err){console.log('error in creating user while signing up'); return}

//               return res.redirect('/users/sign-in');
//           })
//       }else{
//           return res.redirect('back');
//       }

//   });
// }





//new code ************************************************************************

const User = require('../models/user');

module.exports.profile = function(req, res){
  return res.render('user_profile',{
    title: 'User Profile'
  })    
}


// render the sign up page
module.exports.signUp = function(req, res){
  if(req.isAuthenticated()){
    return res.redirect('/users/profile')
  }
    return res.render('user_sign_up', {
        title: "Codeial | Sign Up"
    })
}
// render the sign in page
module.exports.signIn = function(req, res){
  if(req.isAuthenticated()){
    return res.redirect('/users/profile')
  }

  return res.render('user_sign_in', {
      title: "Codeial | Sign In"
  })
}






// get the sign up data
module.exports.create = async function (req, res) {
    if (req.body.password != req.body.confirm_password) {
      return res.redirect("back");
    }
  
    // Find the user by email.
    const user = await User.findOne({ email: req.body.email });
  
    // If the user does not exist, create the user.
    if (!user) {
      await User.create(req.body);
      return res.redirect('/users/sign-in');
    }else{
      return res.redirect("back");
    }
  
  
     
    // Redirect the user to the sign in page.
    // return res.redirect("/users/sign-in");
  };


  // // Sign in and Create a Session for the users

module.exports.createSession = async function (req, res){
  return res.redirect('/')
}

module.exports.destroySession = function(req, res){
  req.logout();
  return res.redirect('/')
}


//old code*************

// sign in and create a session for the user
// module.exports.createSession = function(req, res){

//   // steps to authenticate
//   // find the user
//   User.findOne({ email: req.body.email })
//   .then(user => {
//     if (!user) {
//       // Handle user not found
//       return res.redirect('back');
//     }

//     if (user.password == req.body.password) {
//       // Handle password mismatch
//       console.log("createSession")
//       return res.redirect('back');
//     }

//     // Handle session creation
//     res.cookie('user_id', user.id);
//     return res.redirect('/users/profile');
//   })
//   .catch(err => {
//     console.error('Error in finding user in signing in:', err);
//     return res.status(500).send('Internal server error');
//   });



  

  
// }