/** Some basic setup to our code
 * 1.to navigate your file you have to write cd fileName and enter
 * 2.to create json file you have to write npm init and Enter
 * 3.to create lock.json/node_module and install express file you have to write npm install express and Enter 
 */

 //we need to require Express
  // to create Express
  const { Console } = require('console');
const express = require('express');
  const path = require('path');
  const port = 3100;
// to call/fire up the express
const app  = express();


app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));
app.use(express.urlencoded());
app.use(express.static('assets'));

// //middleware 1**
// app.use(function(req, res, next){
//     req.MyName="Sumit Sharma";
//     // console.log("middleware1");
//     next();
// });
// app.use(function(req, res, next){
//     console.log("MyName form M@2 :- ",req.MyName);
//     // console.log("middleware2");
//     next()
// });




let contactList = [
    {
        name:"Tonny Kakar",
        phone:"8120126862",
        address:"Bhopal"
    },
    {
        name:"Arjith Singh",
        phone:"9135762647",
        address:"Mumbai"
    },
    {
        name:"Vidhyut Jamhwal",
        phone:"9991352756",
        address:"Channai"
    }
];

/**CONTROLLER* */

//to add contect form 
app.post('/create_contact',function(req,res){
    //  return res.redirect('/practice');
    contactList.push({
        name:req.body.name,
        phone:req.body.phone,
        address:req.body.address
    });

    
//we can also using req.body we can add the item to the contect list
    // contactList.push(req.body);


    return res.redirect('/');
    
});



// Returning the response/page 
app.get('/',function(req,res){
    return res.render('home',{title:'My Conntect list',
    contact_list:contactList});
    //res.send ('<h1>Believe in Yourself!</h1>')
});


app.get('/practice',function(req,res){
    return res.render('practice',{title:'I am sumit'});
});


app.get('/practice/school',function(req,res){
    return res.render('school',{
        title:'My School'
    });
});


// for deleting  a contact
app.get('./delete-contact/:phone', function(req,res){
    
    let phone = req.query.phone;

    let contactIndex = contactList.findIndex(contact => contact.phone == phone);
    if(contactIndex != -1){
        contactList.splice(contactIndex,1);
    };
    return res.redirect('back');
});


//to run the server
app.listen(port,function(err){
    if(err){
        console.log("Error in running the server",err);
        
    };
    console.log("Yup!My Express server is running to the port : ",port);
});
